# -*- coding: utf-8 -*-
"""
Created on Wed Mar 17 10:20:47 2021

@author: dries
"""
import scipy as scp
import numpy as np
import matplotlib.pyplot as plt
from scipy.fftpack import fft,fftfreq

class SignalFunctions():
    def __init__(self, samplingfrequency):
        self.Fs = samplingfrequency
    

    #Generate whitenoise
    def generate_whitenoise(self,seconds):
        fs = self.Fs
        N = fs*seconds
        # amp = 2*np.sqrt(2)
        # freq = 1234.0
        noise_power = 0.001 * fs / 2
        time = np.arange(N) / fs
        # x = amp*np.sin(2*np.pi*freq*time)
        x = np.random.normal(scale=np.sqrt(noise_power), size=time.shape)
        return x
     
    def plot_PSD(self,signal,string):
        freqs, psd = scp.signal.welch(signal,self.Fs, nperseg=4096)
        plt.figure(figsize=(5, 4))
        plt.semilogx(freqs, psd)
        plt.title('PSD for '+string)
        plt.xlabel('Frequency')
        plt.ylabel('Power')
        plt.tight_layout()
        return psd
    
    def fftnoise(self,f):
        f = np.array(f, dtype='complex')
        Np = (len(f) - 1) // 2
        phases = np.random.rand(Np) * 2 * np.pi
        phases = np.cos(phases) + 1j * np.sin(phases)
        f[1:Np+1] *= phases
        f[-1:-1-Np:-1] = np.conj(f[1:Np+1])
        return np.fft.ifft(f).real
    
    def generate_band_limited_noise(self,min_freq, max_freq, duration):
        samples = duration * self.Fs
        freqs = np.abs(np.fft.fftfreq(samples, 1/self.Fs))
        f = np.zeros(samples)
        idx = np.where(np.logical_and(freqs>=min_freq, freqs<=max_freq))[0]
        f[idx] = 1
        return self.fftnoise(f)


    def generate_chirp(self,plot):
        time_step = .01
        time_vec = np.arange(0, 70, time_step)
        
        # A signal with a small frequency chirp
        sig = np.sin(0.5 * np.pi * time_vec * (1 + .1 * time_vec))
        if (plot == 1):
            plt.figure(figsize=(8, 5))
            plt.plot(time_vec, sig)
        return sig
    
  
    def fft_plot(self,audio, sampling_rate, title):
        n = len(audio)
        T = 1/sampling_rate
        yf = fft(audio) # creert array met complexe getallen
        xf = fftfreq(n,T)[:n//2]
        fig, ax = plt.subplots()
        ax.plot(xf, 2.0/n * np.abs(yf[0:n//2]))
        plt.grid()
        plt.title(title)
        plt.xlabel('Frequency')
        plt.ylabel('Magnitude')
        plt.show()
        #return 2.0/n * np.abs(yf[0:n//2])
        return yf
    
    
    def plot_pdf(self, samples,window, dummy=1):
        
        hist, bin_edges = np.histogram(samples[:,window], bins=360)
        length = len(samples[:,window])
        pdf = hist/length
        
        if dummy == 1:
            fig, ax = plt.subplots()
            ax.set_title('PDF  for window'+str(window))
            ax.set_xlabel('Angles (°)')
            ax.set_ylabel('Probability')
            ax.plot(pdf, label = 'pdf')
            ax.legend()
            
        return pdf
    
    def plot_smoothed_pdf(self, samples,window):
        pdf = self.plot_pdf(samples,window,dummy='0')
        smoothed_pdf = scp.signal.savgol_filter(pdf,51,5)
        fig, ax = plt.subplots()
        ax.set_title(' smoothed pdf for window'+str(window))
        ax.set_xlabel('Angles (°)')
        ax.set_ylabel('Probability')
        ax.plot(smoothed_pdf, label = 'pdf')
        ax.legend()
        return smoothed_pdf
 
    

        
        
        

    
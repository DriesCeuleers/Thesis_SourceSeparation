# -*- coding: utf-8 -*-
"""
Created on Mon Mar  8 10:08:11 2021

@author: alexa
"""

import scipy as scp
import numpy as np
import matplotlib.pyplot as plt
import mdct

class Transformer():
    def __init__(self, signal0, signal1, signal2, signal3):
        self.signal_A=signal0
        self.signal_B=signal1
        self.signal_C=signal2
        self.signal_D=signal3
        self.rho  = 1.2 # kg/m³
        self.windowsize = 4096
        self.window_shift = self.windowsize*0.5
        self.spacer = 0.02425
        self.fs = 48000
        self.min_freq = 0
        self.max_freq = 4000
        # initialize pdf
        self.pdf = [0]*360
        
        self.filtered_used = 0
        self.bins = [0]*2
            
    
    def get_MDCT(self):
        px =  self.signal_A - self.signal_B
        py = self.signal_D - self.signal_C
        
        mdct_x = mdct.mdct(px, framelength=self.windowsize)
        mdct_y = mdct.mdct(py, framelength=self.windowsize)
        mdct_signal_C = mdct.mdct(self.signal_C, framelength=self.windowsize)
        mdct_signal_D = mdct.mdct(self.signal_D, framelength=self.windowsize)
        mdct_signal_A = mdct.mdct(self.signal_A, framelength=self.windowsize)
        mdct_signal_B = mdct.mdct(self.signal_B, framelength=self.windowsize)
        mdct_signals = (mdct_signal_C + mdct_signal_D + mdct_signal_A + mdct_signal_B)*0.25
        return mdct_x, mdct_y, mdct_signals
    
    
    def get_STFT(self, denoise="no"):
        
        px =  (self.signal_A - self.signal_B)/(self.rho*self.spacer)
        py = (self.signal_C - self.signal_D)/(self.rho*self.spacer)
        
        f,t,STFT_x = scp.signal.stft(px, nperseg = self.windowsize)
        f,t,STFT_y = scp.signal.stft(py, nperseg = self.windowsize)
        f,t,stft_signalC = scp.signal.stft(self.signal_C, nperseg = self.windowsize)
        f,t,stft_signalD = scp.signal.stft(self.signal_D, nperseg = self.windowsize)
        f,t,stft_signalA = scp.signal.stft(self.signal_A, nperseg = self.windowsize)
        f,t,stft_signalB = scp.signal.stft(self.signal_B, nperseg = self.windowsize)
        
        
        if(denoise=="yes"):
            print('denoising is turned on \n')
            stft_signalC = self.denoising(stft_signalC)
            stft_signalD = self.denoising(stft_signalD)
            stft_signalB = self.denoising(stft_signalB)
            stft_signalA = self.denoising(stft_signalA)
            STFT_x = self.denoising(STFT_x)
            STFT_y = self.denoising(STFT_y)
            
        
        STFT_origin = (stft_signalA + stft_signalB + stft_signalC + stft_signalD)*0.25
        return STFT_x, STFT_y, STFT_origin,f,t
    
   
    def get_angles(self, filtered="no",transform="stft"):
        
    
        if transform == "stft":
            STFT_x, STFT_y, STFT_origin,f,t = self.get_STFT()
            I_x = np.imag((STFT_origin)*np.conj(STFT_x))
            I_y = np.imag((STFT_origin)*np.conj(STFT_y))
            angles_rads = np.arctan2(I_y,I_x)
            angles_degr = angles_rads*180/np.pi
            angles_degr_rounded = np.rint(angles_degr)%360
            self.filtered_used = 0
            
            if filtered == "yes":
                self.filtered_used = 1
                highest_freq = self.fs/2
                freq_per_bin = highest_freq / len(f)
                print("--frequency per bin:",freq_per_bin)
                print("--amount of timeframes:",len(t))
                lower = int(round(self.min_freq/freq_per_bin))
                higher = int(round(self.max_freq/freq_per_bin))
                print("--The bins with ids going from",lower,higher , "are correct")
                # initialize array with all 0s and replace correct bins with 1
                self.bins[0]=lower
                self.bins[1]=higher
                array = np.zeros((len(f),len(t)))
                array[lower:higher,:]=1
                return angles_rads*array, angles_degr*array, angles_degr_rounded*array
            else:
                return angles_rads, angles_degr, angles_degr_rounded
            
        elif transform == "mdct":
            px,py,pw = self.get_MDCT()
            I_x = np.real(np.conj(pw)*px)
            I_y = np.real(np.conj(pw)*py)
            angles_rads = np.arctan2(I_y,I_x)
            angles_degr = angles_rads*180/np.pi
            angles_degr_rounded = np.rint(angles_degr)%360
            self.filtered_used = 0
            
            
            if filtered == "yes":
                self.filtered_used = 1
                highest_freq = self.fs/2
                f=np.shape(px)
                freq_per_bin = highest_freq / f[0]
                print("--frequency per bin:",freq_per_bin)
                print("--amount of timeframes:",f[1])
                lower = int(round(self.min_freq/freq_per_bin))
                higher = int(round(self.max_freq/freq_per_bin))
                print("--The bins with ids going from",lower,higher , "are correct")
                # initialize array with all 0s and replace correct bins with 1
                self.bins[0]=lower
                self.bins[1]=higher
                array = np.zeros((f[0],f[1]))
                array[lower:higher,:]=1
                return angles_rads*array, angles_degr*array, angles_degr_rounded*array
            else:
                return angles_rads, angles_degr, angles_degr_rounded
          
            
      
    def plot_angles(self,angles,window,transform):
        column = angles[:,window]
        if self.filtered_used:
            filtered_column = column[self.bins[0]:self.bins[1]]
            hist, bin_edges = np.histogram(filtered_column, bins=360)
            # smoothed_col1 = scp.signal.savgol_filter(hist,51,5)/len(column)
            smoothed_col1 = hist/len(filtered_column)
            fig, ax = plt.subplots()
            ax.set_title('pdf with filtered frequencies for '+str(transform))
            ax.set_xlabel('Angles (°)')
            ax.set_ylabel('magnitude')
            ax.plot(smoothed_col1, label = 'all angles for window'+str(window))
            ax.legend()
            
        else:
            hist, bin_edges = np.histogram(column, bins=360)
            # smoothed_col1 = scp.signal.savgol_filter(hist,51,5)/len(column)
            smoothed_col1 = hist/len(column)
            fig, ax = plt.subplots()
            ax.set_title('pdf with all frequency bins for '+str(transform))
            ax.set_xlabel('Angles (°)')
            ax.set_ylabel('magnitude')
            ax.plot(smoothed_col1, label = 'all angles for window'+str(window))
            ax.legend()
            


    def inv_stft(self, s_hat_0, s_hat_1):
        s_0 = scp.signal.istft(s_hat_0, nperseg = self.windowsize, noverlap = self.window_shift)
        s_1 = scp.signal.istft(s_hat_1, nperseg = self.windowsize, noverlap = self.window_shift)
        return s_0[1], s_1[1]
    
    
    def denoising(self, signal):
        
        alfa=0.0625
        filtered = np.zeros(np.shape(signal),dtype=np.complex_)
        # print('new array has shape: ', np.shape(filtered))
        rows, cols = np.shape(signal)
        # print(cols, '\n')
        filtered[:,0] = signal[:,0]
        i=1
        while i < cols:
            filtered[:,i] = (alfa*signal[:,i] - (1-alfa)*signal[:,i-1])
            i+=1
        return filtered
    
  
    
    

        
        
        
    
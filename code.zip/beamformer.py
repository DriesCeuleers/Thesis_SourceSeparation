# -*- coding: utf-8 -*-
"""
Created on Mon Mar  8 10:08:33 2021

@author: alexa
"""
  
import scipy as scp
import numpy as np
import matplotlib.pyplot as plt
import math
# from Concentration_parameter_finder import *
from Data_analyser import Data_analyser
from scipy import signal
import pandas as pd
#%% Beamformer
'''Deze klasse bepaalt de eigenlijke beamforming. get_beamforming_total() wordt opgeroepen in de main en deze functie
loopt door alle windows ahv functie get_directivity_bin().'''
class Beamformer():
    def __init__(self, pw, angles_degr_rounded, angles_rads,source_pos):
        self.nr_of_sources = 2
        self.source_angles=source_pos
        
        self.pw = pw
        self.angles_degr_rounded = angles_degr_rounded
        self.angles_rads = angles_rads
        # filename = ['dataframes/angles_rads',str(index),'.csv']
        # csv_name = print("".join(filename))
        # pd.DataFrame(angles_rads).to_csv(csv_name)
        
        # frequency respons smoothing
        self.alpha = 0.1 # factor of smoothing of frequency respons
        self.J_LPF_previous = 0
        self.kappas_matrix_opt = 0
        self.mus_matrix_opt=0
        self.weights_matrix=0
        
        
    def get_R(self,index):
        # get R data (for the optimal parameters for each window)
        analyser = Data_analyser(self.source_angles,index)
        self.kappas_matrix_opt, self.mus_matrix_opt, self.weights_matrix = analyser.order_data()
    
        
    def optimize_parameters_for_window(self, column):
        # operations to perform on 1 column (calculate pdf and return optimal parameters)
        angles_degr_rounded = self.angles_degr_rounded
        count = [0]*360
        this_column = angles_degr_rounded[:,column]
        for i in range (len(this_column)):
            count[int(this_column[i])-1] += 1
        pdf = [0]*360
        for i in range (len(count)): 
            pdf[i] = count[i]/len(this_column)  
        # plot some pdfs
        # if (column > 50 and column < 60):
        #     fig, ax = plt.subplots()
        #     ax.plot(pdf)
        #     ax.set_title('Probability density function' + str(column))
        #     ax.set_xlabel('Angles (°)')
        #     ax.set_ylabel('Probability (%)')
                   
        # optimize using R
        kappas = self.kappas_matrix_opt[column] # column actually respresents the row in the matrix
        mus = self.mus_matrix_opt[column]
        weights = self.weights_matrix[column]
        return kappas, mus, weights, pdf
        
    def get_directivity_bin(self, kappas, mus, weights, pdf, column):
        directivity_functions = []
        J_LPF_n = 0
        this_bin = self.angles_rads[:,column] # relevant time frequency window
        # print('the size of this bin is: ',len(this_bin), 'working on col: ',column)
        smoothed_pdf = scp.signal.savgol_filter(pdf,51,5)
        # calculation of directivity function
        for s in range (self.nr_of_sources):
            k = kappas[s]
            #µ = np.deg2rad(self.source_angles[s])
            µ = mus[s]
            vm_n = (np.exp(k*np.cos(this_bin-µ)))/(2*np.pi*scp.special.i0(k))
            J_n = vm_n*weights[s]
            samples = sum(vm_n)
            J_n = (vm_n/samples)*weights[s]
            
        
            # correcting terms (for the weight: weight *= (1+(1-(h1/h2))))² with h1 peak of von mises and h2 peak of pdf at the relevant angle
            temp_index = int(math.floor(np.rad2deg(mus[s])))
            
            term = J_n[temp_index]/smoothed_pdf[temp_index]
            weight =  (1+(1-term))**2
            J_n = J_n*weight
            mean = [np.mean(J_n)]*360
            
            # avoiding high kappa values (R algo geeft soms uitschieters van enorme kappa waarden waar de pdf eigenlijk vlak is)
            if (mean[self.source_angles[s]] > smoothed_pdf[self.source_angles[s]]): 
                kappas[s] = 0
                vm_n = (np.exp(k*np.cos(this_bin-µ)))/(2*np.pi*scp.special.i0(k))
                J_n = vm_n*weights[s]
                samples = sum(vm_n)
                J_n = (vm_n/samples)*weights[s]#*(1+weights[s])
                # correcting terms
                term = J_n[temp_index]/smoothed_pdf[temp_index]
                weight =  (1+(1-term))**2
                J_n = J_n*weight
          
            
            # smooth frequency respons
            if (column == 0): directivity_functions.append(J_n) # for the first frame
            else:
                J_LPF_n = self.smooth_frequencyrespons(J_n)
                directivity_functions.append(J_LPF_n)
                
              # set J_LPF(n-1) as current frame for loop of next frame
            self.J_LPF_previous = J_LPF_n
        
            # # without smoothing
            # directivity_functions.append(J_n)
        
        return directivity_functions[0], directivity_functions[1]
    
       
    
    # function that loops through all windows to calculate the directivity functions
    def get_beamforming_total(self):
        J_0_final = []
        J_1_final = []
        rows, cols = np.shape(self.pw)
        # print(rows)
        # print(len(self.pw[0]))
        for j in range(0,cols):
            kappas, mus, weights, pdf = self.optimize_parameters_for_window(j)
            smoothed_pdf = scp.signal.savgol_filter(pdf,51,5)
            # plotting a fit of certain windows
            if (j >= 60 and j < 68):
                fit, pdf_1, pdf_2 = self.calculate_fit([j/1 for j in kappas], mus, weights, smoothed_pdf,j)
                fig, ax = plt.subplots()
                ax.set_title('Probability density function')
                ax.set_xlabel('Angles (°)')
                ax.set_ylabel('Probability')
                ax.plot(pdf, label = 'pdf')
                #ax.plot(smoothed_pdf, label = 'smooth pdf')
                ax.plot(pdf_1, label = 'component 1')
                ax.plot(pdf_2, label = 'component 2')
                ax.plot(fit, linewidth = 3, color = 'r', label = 'fitted mixture')
                ax.set_title(str(j))
                ax.legend()
                
            # print(str(j),': k: ', [j/1 for j in kappas],' µ: ', mus, ' weights: ', weights)
            J_0_column, J_1_column = self.get_directivity_bin(kappas, mus, weights, pdf, j)
            J_0_final.append(J_0_column)
            J_1_final.append(J_1_column)
            
        # eventual beamforming
        pw = self.pw
        s_hat_0_final = pw*np.transpose(J_0_final)
        s_hat_1_final = pw*np.transpose(J_1_final)
        return s_hat_0_final, s_hat_1_final, J_0_final
    
    def smooth_frequencyrespons(self, J_n):
        J_LPF_n = self.alpha*self.J_LPF_previous + (1-self.alpha)*J_n
        return J_LPF_n
    
    # this calculation is only important for the plotting of fitted windows
    def calculate_fit(self, kappas, mus, weights, smoothed_pdf,j):
        x = np.linspace(0,2*np.pi - (2*np.pi/360), 360)
        # µ1 = np.deg2rad(mus[0])
        # µ2 = np.deg2rad(mus[1])
        µ1 = mus[0]
        µ2 = mus[1]
        vm_1 = np.exp(kappas[0]*np.cos(x-µ1))/(2*np.pi*scp.special.i0(kappas[0]))
        vm_2 = np.exp(kappas[1]*np.cos(x-µ2))/(2*np.pi*scp.special.i0(kappas[1]))
        samples_1 = sum(vm_1)
        samples_2 = sum(vm_2)
        pdf_1 = (vm_1/samples_1) *weights[0]#*(1+weights[0])
        pdf_2 = (vm_2/samples_2) *weights[1]#*(1+weights[1])
        # correcting terms (for the weight: weight *= (1+(1-(h1/h2))))² with h1 peak of von mises and h2 peak of pdf at the relevant angle
        term1 = pdf_1[int(np.round(np.rad2deg(µ1)))]/smoothed_pdf[int(np.round(np.rad2deg(µ1)))]                
        term2 = pdf_2[int(np.round(np.rad2deg(µ2)))]/smoothed_pdf[int(np.round(np.rad2deg(µ2)))]
        weight1 =  (1+(1-term1))**2
        weight2 =  (1+(1-term2))**2
        weight = [weight1, weight2]
        
        pdf_1 = pdf_1*weight[0]
        pdf_2 = pdf_2*weight[1]
        mean_1 = [np.mean(pdf_1)]*360
        mean_2 = [np.mean(pdf_2)]*360
        
        # avoiding high kappa values (R algo geeft soms uitschieters van enorme kappa waarden waar de pdf eigenlijk vlak is)
        correction = False
        if (mean_1[self.source_angles[0]] > smoothed_pdf[self.source_angles[0]]): 
            kappas[0] = 0
            correction = True
            print('window: ',j,' peak: 1 kappas: ',kappas)
            
        if (mean_2[self.source_angles[1]] > smoothed_pdf[self.source_angles[1]]): 
            kappas[1] = 0             
            correction = True
            print('window: ',j,' peak: 2 kappas: ', kappas)
            
        if (correction == True):
            vm_1 = np.exp(kappas[0]*np.cos(x-µ1))/(2*np.pi*scp.special.i0(kappas[0]))
            vm_2 = np.exp(kappas[1]*np.cos(x-µ2))/(2*np.pi*scp.special.i0(kappas[1]))
            samples_1 = sum(vm_1)
            samples_2 = sum(vm_2)
            pdf_1 = (vm_1/samples_1) *weights[0]#*(1+weights[0])
            pdf_2 = (vm_2/samples_2) *weights[1]#*(1+weights[1])
            # correcting terms
            term1 = pdf_1[int(np.round(np.rad2deg(µ1)))]/smoothed_pdf[int(np.round(np.rad2deg(µ1)))]
            term2 = pdf_2[int(np.round(np.rad2deg(µ2)))]/smoothed_pdf[int(np.round(np.rad2deg(µ2)))]
            weight1 =  (1+(1-term1))**2
            weight2 =  (1+(1-term2))**2
            weight = [weight1, weight2]
            
            pdf_1 = pdf_1*weight[0]
            pdf_2 = pdf_2*weight[1]
                   
        # if (j >= 55 and j < 56):
        #     print(pdf_2)
        #     # polar plot of von mises distribution
        #     plt.subplots()
        #     plt.axes(projection='polar')
        #     rads = np.arange(0, 2*np.pi, 2*np.pi/len(pdf_2))
        #     plt.polar(rads, pdf_1, label='first')
        #     plt.polar(rads, pdf_2, label='second')
        #     plt.title('Polar plot of von mises distributions')
        #     plt.legend()
        #     plt.show()
        return np.add(pdf_1, pdf_2), pdf_1, pdf_2
    
     





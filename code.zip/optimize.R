library("dplyr", lib.loc="C:/Users/dries/anaconda3/envs/rstudio/lib/R/library")
library("movMF", lib.loc="C:/Users/dries/anaconda3/envs/rstudio/lib/R/library")

for(i in 0:15){
  dummy = 'dataframes/angles_rads#.csv'
  filename = gsub("#", i, dummy)
  print(filename)
  angles <- read.csv(filename)
  
  nr_of_columns <- ncol(angles)
  optimized_kappas <- c()
  optimized_mus <- c()
  optimized_weights <- c()
  column <- 2 # indexing starts at 1 and first element is row nrs
  while(column <= nr_of_columns){
    #################################### pdf ####################################
      
    #extract column (to get angles of window 'column')
    column_angles <- t(dplyr::select(angles,column))
    column_angles_degr <- round(column_angles*180 / pi, digits = 0)
    column_angles_degr_rounded <- c()
    
    # adapting negative angles
    for (angle in column_angles_degr){
      if (angle < 0){
          angle <- angle + 360
       }
    column_angles_degr_rounded <- c(column_angles_degr_rounded, angle)
    }
     
    # plotting of pdf
    count <- rep(0,360)
    pdf <- rep(0,360)
    for (angle in column_angles_degr_rounded){
      count[angle] <- count[angle]+1
    }
    pdf <- count / length(column_angles_degr_rounded)
    plot(pdf, type = "l",
         main = 'pdf of time window',
         xlab = 'angles',
         ylab = 'pdf'
         )
     
    #################################### von Mises fitting ################################
    
    # try vonmises fitting
    #vm <- movMF(firstcol,'Banerjee_et_al_2005',nruns=50)
    
    pts_on_unit_circle <- c()
    cos_list <- c()
    sin_list <- c()
      
    for (angle in column_angles){
      new_cos <- cos(angle)
      new_sin <- sin(angle)
      cos_list <- c(cos_list, new_cos)
      sin_list <- c(sin_list, new_sin)
    }
          
    pts_on_unit_circle <- cbind(cos_list, sin_list)
    #plot(pts_on_unit_circle)
    #, control = list('Banerjee_et_al_2005')
    d <- movMF(pts_on_unit_circle, 5, nruns = 20, control = list('Banerjee_et_al_2005'))
    µ <- atan2(d$theta[,2], d$theta[,1])
    µ_angle <- µ*180/pi
    kappas <- sqrt(rowSums(d$theta^2))
    weights <- d$alpha
             
    # add optimized values to list
    optimized_kappas <- c(optimized_kappas, as.list(kappas))
    optimized_mus <- c(optimized_mus, as.list(µ))
    optimized_weights <- c(optimized_weights, as.list(weights))
            
                   
    # increase column for while loop
    column <- column + 1
  }
  # write to csv files
  write.csv(optimized_kappas, gsub("#", i,"dataframes/#_optimized_kappas.csv"))
  write.csv(optimized_mus, gsub("#", i,"dataframes/#_optimized_mus.csv"))
  write.csv(optimized_weights, gsub("#", i, "dataframes/#_optimized_weights.csv"))
}

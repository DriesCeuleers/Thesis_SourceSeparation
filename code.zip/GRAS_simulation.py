# -*- coding: utf-8 -*-
"""
Created on Mon Feb  8 14:30:02 2021

@author: alexa
"""

import numpy as np
import matplotlib.pyplot as plt
import pyroomacoustics as pra
import scipy as scp
from scipy.io import wavfile
from transformer import Transformer
from beamformer import Beamformer
from SignalFunctions import SignalFunctions
import pandas as pd



plt.close('all')

# set the random seed
# np.random.seed(500)

# The desired reverberation time and dimensions of the room
rt60 = 0.5  # seconds; the time it takes for the RIR to decay by 60 dB
#room_dim = [15, 15, 6]  # meters
room_dim = [5.5,8,3]

# get the coordinates for a source position in a room.
def get_source_pos(angle, r,height):
    angle = np.deg2rad(angle)
    position=[0]*3
    position[0] = np.cos(angle)*r
    position[1] = np.sin(angle)*r  
    position[2] = height
    return position

# We invert Sabine's formula to obtain the parameters for the ISM simulator
e_absorption, max_order = pra.inverse_sabine(rt60, room_dim)


# import a mono wavfile as the source signal
# the sampling frequency should match that of the room
fs_0, audio0 = wavfile.read('sounds/sentence_male.wav')
fs_1, audio1 = wavfile.read('sounds/sentence_female_2.wav')

# fs_0, audio0 = wavfile.read('sounds/male_filtered.wav')
# fs_1, audio1 = wavfile.read('sounds/female_filtered.wav')

# fs_0, audio0 = wavfile.read('sounds/white_noise.wav')
# fs_1, audio1 = wavfile.read('sounds/white_noise.wav')

# fig, ax = plt.subplots()
# ax.plot(audio0)
# ax.set_title('in')

#Normalize audio
audio0 = (audio0)/np.max(np.abs(audio0))
audio1 = (audio1)/np.max(np.abs(audio1))

#create some sort of room 
#%%
plt.close('all')
sources =  [[30,270],
           [30,255],
           [30,240],
             [30,225],
              [30,210],
              [30,195],
              [30,180],
              [30,165],
              [30,150],
              [30,135],
              [30,120],
              [30,105],
              [30,90],
              [30,75],
              [30,60],
              [30,45]
              ]
amount = len(sources)
px = [0]*amount
py = [0]*amount
pw = [0]*amount
angles_rads = [0]*amount
angles_degr = [0]*amount
angles_degr_rounded = [0]*amount

for index in range(len(sources)):
    # Create the room
    room = pra.ShoeBox(
    room_dim,
    fs=16000,
    materials=pra.Material(e_absorption),
    #○materials=m,
    max_order=0,
    ray_tracing=False,
    air_absorption=True,
    )

    # place the sources and microphone in the room
    mic_loc = [2.75, 4, 1.5]
    
    source1 = get_source_pos(sources[index][0],1.5,0) #man
    source2 = get_source_pos(sources[index][1],1.5,0) #vrouw
    
    # room.add_source([6.634, 6, 1.7], signal=audio0) #source 0
    # room.add_source([8.366, 6.5,1.7], signal=audio1*2) #source 1
    room.add_source(np.add(mic_loc,source1), signal=audio0) #source 0
    room.add_source(np.add(mic_loc,source2), signal=audio1) #source 1
    
    spacer = 0.012127
    mic_b = np.add(mic_loc,[ spacer, 0, 0])
    mic_a = np.add(mic_loc,[-spacer, 0, 0])
    mic_d = np.add(mic_loc,[0 , spacer, 0])
    mic_c = np.add(mic_loc,[0 , -spacer, 0])
    mic_e = np.add(mic_loc,[0 , 0, spacer])
    mic_f = np.add(mic_loc,[0 , 0, -spacer])
    
    # define the locations of the microphones
    # define the locations of the microphones
    mic_locs = np.c_[ # center of mic [2.5, 1, 1.2]; front of GRAS points to source (mic 0 points to source)
        mic_a,
        mic_b,
        mic_c,
        mic_d,
        mic_e,
        mic_f
    ]# 6 G.R.A.S. nabootsen 
    
    # place the array in the room
    room.add_microphone_array(mic_locs)
    
          
    # Simulate sound propagation + Fourier analysis on real signals
    room.simulate()
    # room.plot()
    
    signal_A=room.mic_array.signals[0, :]
    signal_B=room.mic_array.signals[1, :]
    signal_C=room.mic_array.signals[2, :]
    signal_D=room.mic_array.signals[3, :]
    signal_E=room.mic_array.signals[4, :]
    signal_F=room.mic_array.signals[5, :]
    
    # normalize audios
    signal_A = signal_A / np.max(np.abs(signal_A))
    signal_B = signal_B / np.max(np.abs(signal_B))
    signal_C = signal_C / np.max(np.abs(signal_C))
    signal_D = signal_D / np.max(np.abs(signal_D))


    filename = ['roomrecordings/',str(index),'_mic_D.wav']
    filename = "".join(filename)
    wavfile.write(filename,fs_0,np.int16(signal_A/np.max(np.abs(signal_A)) * 32768))
    
    # plot a spectrogram of mic signal
    # fig, ax  = plt.subplots()
    # pxx,  freq, t, cax = ax.specgram(signal_B, Fs=fs_0)
    # fig.colorbar(cax).set_label('Intensity [dB]')
    # ax.set_xlabel('time (s)')
    # ax.set_ylabel('Frequency (Hz)')
    # ax.set_title('Spectrogram of both voices mixture recorder by mic A')
    
    # create object of class and test angles
    audio_transformer = Transformer(signal_A, signal_B, signal_C, signal_D)
    px[index], py[index], pw[index],f,t = audio_transformer.get_STFT()
    angles_rads[index], angles_degr[index], angles_degr_rounded[index] = audio_transformer.get_angles(filtered="no")
    
    # generate csv files for R
    filename = ['dataframes/angles_rads',str(index),'.csv']
    print("".join(filename))
    csv_name = "".join(filename)
    pd.DataFrame(angles_rads[index]).to_csv(csv_name)
   

#%% Run this after R

for i in range(len(sources)-10):
    beamformer = Beamformer(pw[i],angles_degr_rounded[i],angles_rads[i],sources[i])
    beamformer.get_R(i)
    s_hat_0_final, s_hat_1_final, J_0_final = beamformer.get_beamforming_total()
    source1, source2 = audio_transformer.inv_stft(s_hat_0_final, s_hat_1_final)
       

 
    # normalize signal from 0-1, then multily by 32768 to convert to 16bit for wav
    # wavfile.write("signal_A.wav",fs_0,np.int16(signal_A/np.max(np.abs(signal_A)) * 32768))
    filename_male_t = ['split_positions/',str(i),'_split_male.wav']
    filename_male = "".join(filename_male_t)
    print(filename_male)
    
    filename_female_t = ['split_positions/',str(i),'_split_female.wav']
    filename_female = "".join(filename_female_t)
    print(filename_female)
    
    wavfile.write(filename_male,fs_0,np.int16((source1)/np.max(np.abs(source1)) * 32768))
    wavfile.write(filename_female,fs_0,np.int16((source2)/np.max(np.abs(source2)) * 32768))
    

#%% check influence denoising

# f,t,audioA = scp.signal.stft(signal_A, nperseg =4096)
# signal_generator = SignalGenerator(48000)
# signal_filtered = signal_generator.denoising(audioA)
# audioA_filtered = audio_transformer.inv_stft(signal_filtered)
# wavfile.write("signal_A_before_denoising.wav",fs_0,np.int16(signal_A/np.max(np.abs(signal_A)) * 32768))
# wavfile.write("signal_A_after_denoising.wav",fs_0,np.int16(audioA_filtered/np.max(np.abs(audioA_filtered)) * 32768))
# signal_generator.plot_PSD(signal_A,' unfiltered signal ')
# signal_generator.plot_PSD(audioA_filtered,' signal after denoising ')

#%% plot some pdfs
# signal_generator = SignalFunctions(48000)
# signal_filtered = signal_generator.plot_pdf(angles_degr_rounded,51)

#%% inverse tranformation with transformer object
# source1, source2 = audio_transformer.inv_stft(s_hat_0_final, s_hat_1_final)
# source1 = source1
# source2 = source2

# plot output signal
# fig, ax = plt.subplots()
# ax.plot(source1)
# ax.set_title('out')
      
# write wav files
#normalize signal from 0-1, then multily by 32768 to convert to 16bit for wav
# wavfile.write("signal_A.wav",fs_0,np.int16(signal_A/np.max(np.abs(signal_A)) * 32768))

# wavfile.write("split_male_30.wav",fs_0,np.int16((source1)/np.max(np.abs(source1)) * 32768))
# wavfile.write("split_female_135.wav",fs_0,np.int16((source2)/np.max(np.abs(source2)) * 32768))


# plot a spectrogram of output
# fig, ax  = plt.subplots()
# pxx,  freq, t, cax = ax.specgram(source2/2, Fs=fs_0)
# fig.colorbar(cax).set_label('Intensity [dB]')
# ax.set_xlabel('time (s)')
# ax.set_ylabel('Frequency (Hz)')
# ax.set_title('Spectrogram of splitted female voice with kappa=0')

fs_0, test = wavfile.read('male.wav')
plt.plot(test)



# signal_generator = SignalFunctions(48000)
# signal_filtered = signal_generator.plot_PSD(test, 'psd for test')




        

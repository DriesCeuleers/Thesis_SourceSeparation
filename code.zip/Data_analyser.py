# -*- coding: utf-8 -*-
"""
Created on Fri Mar 19 09:17:12 2021

@author: alexa
"""

import pandas as pd
import numpy as np
from sklearn.metrics import mean_squared_error

#%% Data analyser class
class Data_analyser():
    def __init__(self, source_angles, index):
        filename_t = ['dataframes/',str(index),'_optimized_kappas.csv']
        filename = "".join(filename_t)
        self.kappas = (pd.read_csv(filename)).iloc[0]   
        
        filename_t = ['dataframes/',str(index),'_optimized_mus.csv']
        filename = "".join(filename_t)
        self.mus = (pd.read_csv(filename)).iloc[0]   
        
        filename_t = ['dataframes/',str(index),'_optimized_weights.csv']
        filename = "".join(filename_t)
        self.weights = (pd.read_csv(filename)).iloc[0]   
        
        
        # self.kappas = (pd.read_csv("dataframes/optimized_kappas.csv")).iloc[0] # get correct row (other one is indexing)
        # self.mus = (pd.read_csv("dataframes/optimized_mus.csv")).iloc[0]
        # self.weights = (pd.read_csv("dataframes/optimized_weights.csv")).iloc[0]
        self.source_angles = source_angles
        
        self.nr_of_sources = 2
        self.nr_of_components = 5
        # divide data (too difficult in R)
        
        
    def order_data(self): # data came in as an array, put it in matrix with every row respresenting the values of 1 pdf 
        kappas_matrix = []
        mus_matrix = []
        weights_matrix = []
    
        counter = 0
        temp_list_k = []
        temp_list_µ = []
        temp_list_weights = []
        for i in range(len(self.kappas)-1):
            temp_list_k.append(self.kappas[i+1]) # +1 because first element is indexing
            temp_list_µ.append(self.mus[i+1])
            temp_list_weights.append(self.weights[i+1])
            counter += 1
            if (counter == self.nr_of_components):
                # get the most optimal paramteres (from 5 possible values)
                temp_list_k, temp_list_µ, temp_list_weights = self.get_best_fitting(temp_list_k, temp_list_µ, temp_list_weights)
                temp_list_k, temp_list_µ, temp_list_weights = self.order_with_increasing_value(temp_list_k, temp_list_µ, temp_list_weights)
                kappas_matrix.append(temp_list_k)
                mus_matrix.append(temp_list_µ)
                weights_matrix.append(temp_list_weights)
                temp_list_k = []
                temp_list_µ = []
                temp_list_weights = []
                counter = 0
        return kappas_matrix, mus_matrix, weights_matrix
    
    # index of certain peak may differ for each row in matrix, this method ordens with increasing µ value
    def order_with_increasing_value(self, kappas_row, mus_row, weights_row):
        temp_list_k = kappas_row
        temp_list_µ = mus_row
        temp_list_weights = weights_row
        final_kappas_row = []
        final_mus_row = []
        final_weights_row = []
        for i in range (self.nr_of_sources):
            min_value = np.min(temp_list_µ)
            for j in range (len(temp_list_µ)):
                if (j < len(temp_list_µ)):
                    if (temp_list_µ[j] == min_value):
                        # add min value to final rows to return
                        final_kappas_row.append(temp_list_k[j])
                        final_mus_row.append(temp_list_µ[j])
                        final_weights_row.append(temp_list_weights[j])
                        # remove min value from temporary lists
                        temp_list_k.remove(temp_list_k[j])
                        temp_list_µ.remove(temp_list_µ[j])
                        temp_list_weights.remove(temp_list_weights[j])
        return final_kappas_row, final_mus_row, final_weights_row
    
    
    def get_best_fitting(self, kappas_row, mus_row, weights_row): # get data for best fitting µ values
        temp_list_k = kappas_row
        temp_list_µ = mus_row
        temp_list_weights = weights_row
        for angle_index in range(len(temp_list_µ)):
            if (temp_list_µ[angle_index] < 0): temp_list_µ[angle_index] += 2*np.pi
        final_kappas_row = []
        final_mus_row = []
        final_weights_row = []
        '''Per source wordt een array van de 2 dichtstbij liggende waarden opgeslagen.
        Van deze 2 wordt diegene met de hoogste kappa waarde gekozen'''
        # add 2 closest values to array
        closest_µ = []
        closest_kappa = []
        closest_weight = []
        for j in range (self.nr_of_sources): # loop for every source
            for i in range (2): # loop for the 2 nearest values
                index = self.find_nearest(temp_list_µ, np.deg2rad(self.source_angles[j]))
                closest_µ.append(temp_list_µ[index])
                closest_kappa.append(temp_list_k[index])
                closest_weight.append(temp_list_weights[index])
                # remove from temporary lists
                temp_list_k.remove(temp_list_k[index])
                temp_list_µ.remove(temp_list_µ[index])
                temp_list_weights.remove(temp_list_weights[index])
            # take max kappa value of the arrays
            max_index = np.argmax(closest_kappa)
            if (np.abs(closest_µ[max_index] - np.deg2rad(self.source_angles[j])) > 0.26):
               closest_µ.remove(closest_µ[max_index])
               closest_kappa.remove(closest_kappa[max_index])
               closest_weight.remove(closest_weight[max_index])
               max_index = 0
            if (closest_kappa[max_index] < 182): # kappa corrsponding to a 10° beamwidth (chosen as maximum)
                final_kappas_row.append(closest_kappa[max_index])
            else: final_kappas_row.append(182)
            final_mus_row.append(closest_µ[max_index])
            final_weights_row.append(closest_weight[max_index])
            # reset arrays
            closest_µ = []
            closest_kappa = []
            closest_weight = []        
        return final_kappas_row, final_mus_row, final_weights_row
            
    def find_nearest(self, array, value):
        #array = np.asarray(array)
        idx = np.argmin([np.abs(j - value) for j in array])
        return idx
  



    